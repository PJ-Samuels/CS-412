export let config = {
  apiKey: '6d13b989d2175d527ad89638956aec97',
  baseURL: 'http://api.openweathermap.org/data/2.5/weather?q='
}
