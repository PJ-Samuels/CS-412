import { Component } from '@angular/core';
import { WxServiceService as WxService} from './wx-service.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'httpClient';
  currentWeather = {
    temperature: 0,
    pressure: 0,
    humidity: 0
  };

  city: string = "Boston";
  units: string = "imperial";
//Moved these into the FormGroup for Way 3
  cityControl2: FormControl = new FormControl('boston',
    [Validators.required,Validators.max(6)]);
  unitsControl2: FormControl = new FormControl('imperial');


//   weatherFormGroup :FormGroup = new FormGroup({
//     cityControl: new FormControl('boston', Validators.required),
//     unitsControl:  new FormControl()
// });

  //Use FormBuilder service as a quick way to set up a form group
  //needs FormBuilder service injected
weatherFormGroup = this.form.group({
  cityControl: ['boston', Validators.required],
  unitsControl: [''],
  subform: this.form.group({
    detail: ['']
  })
})

  constructor(private wxService: WxService, private form: FormBuilder) {}

  getWeather() {
    this.wxService.getWeather(this.city).subscribe(
      response => {
        //this.currentWeather = response['main']['temp']; // similar to main.temp
        this.currentWeather= {
          temperature: response['main']['temp'],
          //temperature: response.main.temp,
          pressure: response['main']['pressure'],
          humidity: response['main']['humidity'],
        }
      }
    );
  }
  getWX() {
    this.wxService.getWeather(this.city).subscribe(
      response => {
        console.log(`WX: ${response}`);
      }
    )
  }
  getWeatherByCity() {
    this.wxService.getWeatherByCity(this.city, this.units).subscribe(
      response => {
        this.currentWeather = response['main'];// similar to current.temp
        this.currentWeather = {
          temperature: response['main']['temp'],
          pressure: response['main']['pressure'],
          humidity: response['main']['humidity'],
        }
        console.log(`main looks like this: ${response['main']}`)
      }
    );
  }
  getWeatherByCityWay2() {
    this.wxService.getWeatherByCity(this.cityControl2.value, this.unitsControl2.value).subscribe(
      response => {
        this.currentWeather = response['main'];// similar to current.temp
        this.currentWeather = {
          temperature: response['main']['temp'],
          pressure: response['main']['pressure'],
          humidity: response['main']['humidity'],
        }
        console.log(`main looks like this: ${response['main']}`)
      }
    );
  }
  getWeatherByCityWay3() {
  //do all of your form checking here...

    //then call the service..(*separation of responsibility*)
    this.wxService.getWeatherByFormGroup(this.weatherFormGroup).subscribe(
      response => {
        this.currentWeather = response['main'];// similar to current.temp
        this.currentWeather = {
          temperature: response['main']['temp'],
          pressure: response['main']['pressure'],
          humidity: response['main']['humidity'],
        }
        console.log(`main looks like this: ${response['main']}`)
      }
    );
  }

}
