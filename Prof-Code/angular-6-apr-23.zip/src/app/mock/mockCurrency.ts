export const curData = {
  "success": true,
  "terms": "https://currencylayer.com/terms",
  "privacy": "https://currencylayer.com/privacy",
  "timestamp": 1560876845,
  "source": "USD",
  "quotes": {
  "USDEUR": 0.892966,
    "USDGBP": 0.79706,
    "USDJPY": 108.475987
    }
}
