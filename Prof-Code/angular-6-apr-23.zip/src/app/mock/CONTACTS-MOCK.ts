import {CONTACT} from '../models/contactModel';

export const CONTACTS: CONTACT[] =
  [
    {
      _id: '595665efbe01b3c94d573d8b',
      name: 'Fred',
      UID: 'sd',
      department: 'asdaaaa',

    },
    {
      _id: '5b21ae3c11000adbca197900',
      name: 'Perry',
      UID: '12345',
      department: 'BUCS'
    },
    {
      _id: '5b29864e1b501cc8a838bf9a',
      name: 'Coll',
      department: 'BUPHOTO',
      UID: 'sd1',

    },
    {
      _id: '5b29950b1b501cc8a838bf9b',
      name: 'Bob',
      department: 'BUBOB',
      UID: 'sd2',

    },

    {
      _id: '5b29a7f0a93ca7ce819aac9a',
      name: 'erik',
      department: 'buerik',
      UID: 'sd332',

    },
    {
      _id: '5b29a95a73b667cedc66ecca',
      name: 'ed',
      department: 'ddd',
      UID: 'U43242342',

    },
    {
      _id: '5b29ab8573b667cedc66eccb',
      name: 'don',
      department: 'ddd',
      UID: 'U5312323'

    }
  ]

