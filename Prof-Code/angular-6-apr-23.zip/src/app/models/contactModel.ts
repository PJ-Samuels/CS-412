export class CONTACT {
  _id: string | undefined;
  name: string | undefined;
  UID: string | undefined;
  department: string | undefined;
}
