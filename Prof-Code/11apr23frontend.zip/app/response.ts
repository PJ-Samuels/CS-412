export class  Response {
input: string | undefined;
  reversed: string | undefined;
}
